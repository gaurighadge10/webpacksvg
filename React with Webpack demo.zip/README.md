# react-with-webpack

This repo contains sample code of how to setup a react app with Webpack and Babel.

Find the whole tutorial over here: https://anubhav7x.hashnode.dev/setup-a-react-app-using-webpack-and-babel
