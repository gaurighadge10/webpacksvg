import React from "react";
import HelloWorld from "./components/HelloWorld";
import RenderForm from "./components/RenderForm";

const App = () => {
  return (
    <div>
      <center>
      <HelloWorld />
      <RenderForm />
      </center>
    </div>
  );
};

export default App;
