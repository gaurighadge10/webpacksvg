import React from "react";
import Call from "../assets/images/call.png";
import Arrow from "../assets/images/arrow.svg";
import Mobile from "../assets/images/mobile.svg";

const HelloWorld = () => {
  return (
    <>
    <div>
 
      <h1>Hello World</h1>
    </div>
    {/* <img src={Call} alt="BigCo Inc. logo"/>
    <img src={Arrow} alt="No arrow "/>
    <img src={Mobile} alt="No arrow "/> */}
    </>
  );
};

export default HelloWorld;
